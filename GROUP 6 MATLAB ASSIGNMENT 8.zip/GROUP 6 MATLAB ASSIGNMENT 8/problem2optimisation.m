clc;
clear;
close all;

%% QUESTION 2: OPTIMUM TRACTOR SPEED USING SIX OPTIMIZATION SOLVERS

% Objective function: Fuel consumption (L/hr)
F = @(v) 0.5*v.^2 - 4*v + 15;

% Speed constraints (km/hr)
lb = 2;
ub = 12;

% Initial speed
x0 = 6;

% Ensure repeatable results for stochastic solvers
rng(1);

%% 1. GENETIC ALGORITHM (GA)

options_ga = optimoptions('ga','Display','off');

[v_ga, fuel_ga] = ga(F,1,[],[],[],[],lb,ub,[],options_ga);


%% 2. FMINCON

options_fmincon = optimoptions('fmincon', ...
    'Display','off', ...
    'Algorithm','sqp');

[v_fmincon, fuel_fmincon] = fmincon(F,x0,[],[],[],[], ...
    lb,ub,[],options_fmincon);


%% 3. PARTICLE SWARM OPTIMIZATION

options_pso = optimoptions('particleswarm','Display','off');

[v_pso, fuel_pso] = particleswarm(F,1,lb,ub,options_pso);


%% 4. PATTERN SEARCH

options_pattern = optimoptions('patternsearch','Display','off');

[v_pattern, fuel_pattern] = patternsearch(F,x0,[],[],[],[], ...
    lb,ub,[],options_pattern);


%% 5. SURROGATE OPTIMIZATION

options_surrogate = optimoptions('surrogateopt', ...
    'Display','off', ...
    'MaxFunctionEvaluations',100);

[v_surrogate, fuel_surrogate] = surrogateopt(F,lb,ub, ...
    options_surrogate);


%% 6. SIMULATED ANNEALING

options_sa = optimoptions('simulannealbnd','Display','off');

[v_sa, fuel_sa] = simulannealbnd(F,x0,lb,ub,options_sa);


%% DISPLAY RESULTS

Solver = {
    'GA'
    'FMINCON'
    'PARTICLESWARM'
    'PATTERNSEARCH'
    'SURROGATEOPT'
    'SIMULANNEALBND'
};

Optimum_Speed = [
    v_ga
    v_fmincon
    v_pso
    v_pattern
    v_surrogate
    v_sa
];

Minimum_Fuel = [
    fuel_ga
    fuel_fmincon
    fuel_pso
    fuel_pattern
    fuel_surrogate
    fuel_sa
];

Results = table(Solver,Optimum_Speed,Minimum_Fuel);

disp('OPTIMUM TRACTOR SPEED RESULTS');
disp(Results);


%% IDENTIFY THE BEST RESULT

[minimum_fuel,index] = min(Minimum_Fuel);

fprintf('\nBEST OPTIMIZATION RESULT\n');
fprintf('------------------------\n');
fprintf('Solver: %s\n',Solver{index});
fprintf('Optimum speed: %.4f km/hr\n',Optimum_Speed(index));
fprintf('Minimum fuel consumption: %.4f L/hr\n',minimum_fuel);


%% PLOT FUEL CONSUMPTION AND OPTIMUM SPEEDS

v = linspace(lb,ub,200);

fig1 = figure;   % handle stored so the figure can be saved later

plot(v,F(v),'b','LineWidth',2);
hold on;

plot(v_ga,fuel_ga,'ro','MarkerSize',8,'MarkerFaceColor','r');
plot(v_fmincon,fuel_fmincon,'gs','MarkerSize',8,'MarkerFaceColor','g');
plot(v_pso,fuel_pso,'m^','MarkerSize',8,'MarkerFaceColor','m');
plot(v_pattern,fuel_pattern,'kd','MarkerSize',8,'MarkerFaceColor','k');
plot(v_surrogate,fuel_surrogate,'c*','MarkerSize',10);
plot(v_sa,fuel_sa,'yo','MarkerSize',8,'MarkerFaceColor','y');

xlabel('Tractor Speed (km/hr)');
ylabel('Fuel Consumption (L/hr)');

title('Tractor Speed Optimization Using Six Solvers');

legend('Fuel Consumption','GA','FMINCON','PARTICLESWARM', ...
    'PATTERNSEARCH','SURROGATEOPT','SIMULANNEALBND', ...
    'Location','best');

grid on;
hold off;


%% SAVE THE PLOT AND RESULTS

outDir = fullfile(pwd, 'Tractor_Speed_Plots');   % folder in the current directory
if ~exist(outDir, 'dir')
    mkdir(outDir);
end

plotFile = fullfile(outDir, 'Tractor_Speed_Optimization.png');
try
    exportgraphics(fig1, plotFile, 'Resolution', 300);   
catch
    saveas(fig1, plotFile);                              
end

writetable(Results, fullfile(outDir, 'Tractor_Speed_Results.csv'));

fprintf('\nPlot and results saved in: %s\n', outDir);
