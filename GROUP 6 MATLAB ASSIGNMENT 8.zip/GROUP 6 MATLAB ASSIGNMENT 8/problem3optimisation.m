%% PROBLEM 3: OPTIMIZATION OF A RECTANGULAR IRRIGATION CANAL
% Minimize wetted perimeter P = b + 2h
% Subject to: b*h >= 2,  0.5 <= b <= 4,  0.5 <= h <= 3
% Solvers compared: fmincon, ga, particleswarm, patternsearch,
%                   surrogateopt, simulannealbnd

clear; clc; close all;

%% Problem definition
lb = [0.5 0.5];                 % lower bounds [b h]
ub = [4   3  ];                 % upper bounds [b h]
x0 = [3   1.5];                 % starting point (feasible: 3*1.5 = 4.5 >= 2)
Amin = 2;                       % minimum cross-sectional area (m^2)

obj     = @(x) x(1) + 2*x(2);                          % wetted perimeter
nonlcon = @(x) deal(Amin - x(1)*x(2), []);             % c(x) <= 0  ->  2 - b*h <= 0

% Solvers without native nonlinear constraints use a penalty function
penObj  = @(x) x(1) + 2*x(2) + 1e5*max(0, Amin - x(1)*x(2))^2;

% surrogateopt takes constraints through a struct
surObj  = @(x) struct('Fval', x(1) + 2*x(2), 'Ineq', Amin - x(1)*x(2));

%% 2. Solver options (Display off, fixed seed for repeatability)
optFmin = optimoptions('fmincon',        'Display','off');
optGA   = optimoptions('ga',             'Display','off');
optPSO  = optimoptions('particleswarm',  'Display','off');
optPS   = optimoptions('patternsearch',  'Display','off');
optSO   = optimoptions('surrogateopt',   'Display','off', 'MaxFunctionEvaluations',200);
optSA   = optimoptions('simulannealbnd', 'Display','off');

names  = {'fmincon','ga','particleswarm','patternsearch','surrogateopt','simulannealbnd'};
runner = {
    @() fmincon(obj, x0, [],[],[],[], lb, ub, nonlcon, optFmin)
    @() ga(obj, 2, [],[],[],[], lb, ub, nonlcon, optGA)
    @() particleswarm(penObj, 2, lb, ub, optPSO)
    @() patternsearch(obj, x0, [],[],[],[], lb, ub, nonlcon, optPS)
    @() surrogateopt(surObj, lb, ub, optSO)
    @() simulannealbnd(penObj, x0, lb, ub, optSA)
};

%% 3. Run each solver, measure average time
nRuns = 5;
nSol  = numel(names);
tAvg  = zeros(nSol,1);
bOpt  = zeros(nSol,1);
hOpt  = zeros(nSol,1);

for k = 1:nSol
    rng(1);
    runner{k}();                         
    tRun = zeros(nRuns,1);
    for r = 1:nRuns
        tic;
        x = runner{k}();
        tRun(r) = toc;
    end
    tAvg(k) = mean(tRun);
    bOpt(k) = x(1);
    hOpt(k) = x(2);
end

Popt = bOpt + 2*hOpt;                    % wetted perimeter found
Aopt = bOpt .* hOpt;                     % area achieved

%% 4. Results table
Results = table(names', bOpt, hOpt, Aopt, Popt, tAvg, ...
    'VariableNames', {'Solver','b_m','h_m','Area_m2','P_m','AvgTime_s'});
disp(Results);

fprintf('\nAnalytical solution: b = 2 m, h = 1 m, P_min = 4 m\n');

%% 5. Plot 1: Feasible region, contours of P, and optimum
[B,H] = meshgrid(linspace(0.5,4,300), linspace(0.5,3,300));
P = B + 2*H;
feasible = (B.*H >= Amin);

figure('Name','Feasible region','Color','w');
contourf(B, H, P, 15, 'LineColor','none'); hold on;
colorbar; ylabel(colorbar,'Wetted perimeter P (m)');
% shade infeasible zone
hInf = pcolor(B, H, double(~feasible)); set(hInf,'EdgeColor','none');
colormap(parula); 
set(hInf,'FaceAlpha',0.55,'FaceColor','flat'); 
bb = linspace(Amin/3, 4, 200);
plot(bb, Amin./bb, 'r-', 'LineWidth', 2);            % area constraint bh = 2
plot(2, 1, 'kp', 'MarkerSize', 16, 'MarkerFaceColor','y');
text(2.1, 1.15, 'Optimum (2, 1)', 'FontWeight','bold');
xlabel('Canal width b (m)'); ylabel('Water depth h (m)');
title('Problem 3: Feasible region and optimum');
legend({'','','bh = 2 (constraint)','Optimum'}, 'Location','northeast');
grid on; hold off;

%% 6. Plot 2: P along the active constraint (h = 2/b)
bv = linspace(0.67, 4, 300);
Pv = bv + 4./bv;

figure('Name','P vs b','Color','w');
plot(bv, Pv, 'b-', 'LineWidth', 2); hold on;
plot(2, 4, 'ro', 'MarkerSize', 10, 'MarkerFaceColor','r');
xlabel('Canal width b (m)'); ylabel('Wetted perimeter P (m)');
title('P = b + 4/b  (after substituting h = 2/b)');
text(2.1, 4.15, 'Minimum: b = 2 m, P = 4 m');
grid on; hold off;

%% 7. Plot 3: Solver timing comparison
figure('Name','Solver timing','Color','w');
bar(categorical(names, names), tAvg);
ylabel('Average time (s)');
title('Time taken by each solver (Problem 3)');
grid on;

%% 8. Plot 4: Solution quality (perimeter found)
figure('Name','Solver accuracy','Color','w');
bar(categorical(names, names), Popt); hold on;
yline(4, 'r--', 'Analytical P_{min} = 4 m', 'LineWidth', 1.5);
ylabel('Wetted perimeter P (m)');
ylim([3.9 max(Popt)+0.1]);
title('Perimeter found by each solver');
grid on; hold off;
%% 9. Save all plots as PNG images
outDir = fullfile(pwd, 'Problem3_Plots');
if ~exist(outDir, 'dir')
    mkdir(outDir);
end

figs  = findobj('Type', 'figure');         
for i = 1:numel(figs)
    f    = figs(i);
    name = strrep(get(f, 'Name'), ' ', '_');  
    if isempty(name)
        name = sprintf('Figure_%d', f.Number);
    end
    file = fullfile(outDir, [name '.png']);
    try
        exportgraphics(f, file, 'Resolution', 300);   
    catch
        saveas(f, file);                              
    end
    fprintf('Saved: %s\n', file);
end
%% save the results table
writetable(Results, fullfile(outDir, 'Problem3_Results.csv'));
fprintf('\nAll plots saved in: %s\n', outDir);



