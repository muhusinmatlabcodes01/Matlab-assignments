%% IRRIGATION-WATER ALLOCATION
clear;
clc;
close all;

%% Define the problem
% x = water allocated to tomatoes, in units of 100 m^3.
% Water allocated to cabbages = 30 - x.
% Exactly 3000 m^3 must be allocated.
% Neither field can receive more than 2000 m^3.
% Therefore, the allowable range is 10 <= x <= 20.

lb = 10;       % Lower bound
ub = 20;       % Upper bound
x0 = 15;       % Starting guess

% Total predicted yield, in tonnes.
yield = @(x) 8*x - 0.2*x.^2 + 6*(30-x) - 0.15*(30-x).^2;

% Minimize negative yield to maximize actual yield.
objective = @(x) -yield(x);

% Make the random searches reproducible.
rng(1);

%% Solve using Genetic Algorithm: ga

options = optimoptions('ga', 'Display', 'off');

tic;
[x1, f1] = ga(objective, 1, [], [], [], [],lb, ub, [], options);
time1 = toc;

%% Solve using fmincon

options = optimoptions('fmincon', 'Display', 'off');

tic;
[x2, f2] = fmincon(objective, x0, [], [], [], [], lb, ub, [], options);
time2 = toc;

%% Solve using Particle Swarm: particleswarm

options = optimoptions('particleswarm', 'Display', 'off');

tic;
[x3, f3] = particleswarm(objective, 1, lb, ub, options);
time3 = toc;

%% Solve using Pattern Search: patternsearch

options = optimoptions('patternsearch', 'Display', 'off');

tic;
[x4, f4] = patternsearch(objective, x0, [], [], [], [],lb, ub, [], options);
time4 = toc;

%% Solve using Surrogate Optimization: surrogateopt

options = optimoptions('surrogateopt','Display', 'off', 'PlotFcn', [],'MaxFunctionEvaluations', 100);

tic;
[x5, f5] = surrogateopt(objective, lb, ub, options);
time5 = toc;

%% Solve using Simulated Annealing: simulannealbnd

options = optimoptions('simulannealbnd','Display', 'off','MaxIterations', 500);

tic;
[x6, f6] = simulannealbnd(objective, x0, lb, ub, options);
time6 = toc;

%% Collect the results
% Semicolons place values in separate rows.

solverNames = {'ga'; 'fmincon'; 'particleswarm';'patternsearch'; 'surrogateopt';'simulannealbnd'};

tomatoUnits = [x1; x2; x3; x4; x5; x6];

% Convert allocation units into m^3.
tomatoWater = 100 * tomatoUnits;
cabbageWater = 100 * (30 - tomatoUnits);

% Calculate each crop's predicted yield.
tomatoYield = 8*tomatoUnits - 0.2*tomatoUnits.^2;

cabbageUnits = 30 - tomatoUnits;
cabbageYield = 6*cabbageUnits - 0.15*cabbageUnits.^2;

% Reverse the negative sign to obtain actual total yield.
totalYield = -[f1; f2; f3; f4; f5; f6];

computationTime = [time1; time2; time3; time4; time5; time6];

%% Display a results table

results = table(solverNames, tomatoWater, cabbageWater, tomatoYield, cabbageYield, totalYield, computationTime,'VariableNames', {'Solver', 'TomatoWater_m3','CabbageWater_m3', 'TomatoYield_t', 'CabbageYield_t', ...
    'TotalYield_t', 'Time_seconds'});

disp(results);

%% Plot total yield against tomato water allocation

x = linspace(lb, ub, 200);

% Analytical reference solution:
% Total yield = 45 + 11*x - 0.35*x^2.
% Its derivative is zero when x = 11/0.7.
xOptimal = 11 / 0.7;
yieldOptimal = yield(xOptimal);

fig1 = figure;   % handle stored so the figure can be saved later

plot(100*x, yield(x), 'b-', 'LineWidth', 2);
hold on;

plot(100*xOptimal, yieldOptimal, 'ro','MarkerSize', 9, 'MarkerFaceColor', 'r');

xlabel('Water allocated to tomatoes (m^3)');
ylabel('Total predicted yield (tonnes)');
title('Total Yield versus Water Allocation');
legend('Total yield', 'Analytical optimum', 'Location', 'best');
grid on;

%% Plot computation times

fig2 = figure;

bar(computationTime);

set(gca, 'XTick', 1:6, 'XTickLabel', solverNames);
xtickangle(30);

ylabel('Computation time (seconds)');
title('Computation Time for Each Solver');
grid on;

%% Plot total yields obtained by the solvers

fig3 = figure;

bar(totalYield);

set(gca, 'XTick', 1:6, 'XTickLabel', solverNames);
xtickangle(30);

ylabel('Total predicted yield (tonnes)');
title('Total Yield Obtained by Each Solver');
grid on;

%% Display the reference answer

fprintf('\nAnalytical reference answer:\n');
fprintf('Water to tomatoes = %.2f m^3\n', 100*xOptimal);
fprintf('Water to cabbages = %.2f m^3\n', 100*(30-xOptimal));
fprintf('Maximum total yield = %.2f tonnes\n', yieldOptimal);



%% Save all plots as PNG images

outDir = fullfile(pwd, 'Irrigation_Plots');  
if ~exist(outDir, 'dir')
    mkdir(outDir);
end

figHandles = [fig1, fig2, fig3];
figNames   = {'Yield_vs_Water_Allocation', ...
              'Computation_Time', ...
              'Total_Yield_by_Solver'};

for i = 1:numel(figHandles)
    file = fullfile(outDir, [figNames{i} '.png']);
    try
        exportgraphics(figHandles(i), file, 'Resolution', 300);
    end
    fprintf('Saved: %s\n', file);
end

fprintf('\nAll plots saved in: %s\n', outDir);
